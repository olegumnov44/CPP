#pragma once

#include <string>
#include <vector>


/*      --------- Не прошло тренажёр 5 спринта ------
struct Document {
    Document() = default;
    Document(int id, double relevance, int rating);
    int id;
    double relevance;
    int rating;
};
*/

struct Document {

    Document() = default;

    Document(int id_, double relevance_, int rating_)
        : id(id_)
        , relevance(relevance_)
        , rating(rating_)
    {}

    int id = 0;
    double relevance = 0.0;
    int rating = 0;
};

enum class DocumentStatus {
    ACTUAL,
    IRRELEVANT,
    BANNED,
    REMOVED,
};

std::ostream& operator<<(std::ostream& out, const Document& document);

void PrintDocument(const Document& document);

void PrintMatchDocumentResult(int document_id, const std::vector<std::string_view>& words, DocumentStatus status);
