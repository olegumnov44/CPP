#pragma once

#include <string>
#include <vector>
#include <set>

using namespace std::string_literals;


std::vector<std::string_view> SplitIntoWords(std::string_view text);

template <typename StringContainer>
std::set<std::string, std::less<>> MakeUniqueNonEmptyStrings(const StringContainer& strings)
{
    std::set<std::string, std::less<>> non_empty_strings;
    for (std::string_view word_sv : strings) {
        const std::string& word = std::string(word_sv);
        if (!word.empty()) {
            non_empty_strings.insert(word);     // Extract non-empty stop words
        }
    }
    return non_empty_strings;
}
