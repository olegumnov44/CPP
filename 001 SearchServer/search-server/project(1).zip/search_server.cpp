#include <algorithm>
#include <cmath>
#include <deque>

#include "search_server.h"
#include "log_duration.h"

using namespace std;

SearchServer::SearchServer(std::string_view stopwords_text)
    : SearchServer(SplitIntoWords(stopwords_text))
{}

SearchServer::SearchServer(const std::string& stopwords_text)
    : SearchServer(SplitIntoWords(std::string_view(stopwords_text)))
{}

void SearchServer::AddDocument(int document_id, std::string_view document,
                               DocumentStatus status, const std::vector<int>& ratings) {
    if (document_id < 0) {
        throw invalid_argument("Id less then null"s);
    }
    if (__id_docdata_.count(document_id) > 0) {
        throw invalid_argument("This id exist already"s);
    }
    if (!SearchServer::IsValidWord(document)) {
        throw invalid_argument("Found a special symbol(s) in the document"s);
    }
    std::vector<std::string_view> words = SearchServer::SplitIntoWordsNoStop(document);

    const double inv_word_count = 1.0 / words.size();
    for (std::string_view word_sv : words) {
        const std::string& word = std::string(word_sv);
        __word_to__id_freq_[word][document_id] += inv_word_count;
        __id_to__word_freq_[document_id][word] += inv_word_count;
    }
    __id_docdata_.emplace(document_id, DocumentData{SearchServer::ComputeAverageRating(ratings), status});
    __id_.insert(document_id);
}

std::vector<Document> SearchServer::FindTopDocuments(std::string_view raw_query,
                                                     DocumentStatus status) const {
    return SearchServer::FindTopDocuments(
        raw_query, [status](int document_id, DocumentStatus document_status, int rating) {
            return document_status == status;
        }
    );
}

std::vector<Document> SearchServer::FindTopDocuments(std::string_view raw_query) const {
    return SearchServer::FindTopDocuments(raw_query, DocumentStatus::ACTUAL);
}

int SearchServer::GetDocumentCount() const {
    return __id_docdata_.size();
}

std::set<int>::const_iterator SearchServer::begin() const {
    return __id_.begin();
}

std::set<int>::const_iterator SearchServer::end() const {
    return __id_.end();
}

std::tuple<std::vector<std::string_view>, DocumentStatus> SearchServer::MatchDocument
    (std::string_view raw_query, int document_id) const {

 //for (size_t i = 1; i <= 50000; ++i) { if ( (i / sqrt(i)) > 100'000'0) { std::cout << "OK" << std::endl; } }

    if (count(__id_.begin(), __id_.end(), document_id) == 0) {
        throw std::out_of_range("Id doesn't exist");
    }

    if (__id_to__word_freq_.at(document_id).empty()) {
        return {{}, __id_docdata_.at(document_id).status};
    }

    const SearchServer::Query query = SearchServer::ParseQuery(raw_query);
    for (std::string_view word_sv : query.minus_words) {
        const std::string& word = std::string(word_sv);
        if (__word_to__id_freq_.count(word) == 0) { continue; }
        if (__word_to__id_freq_.at(word).count(document_id) > 0) {
            return {{}, __id_docdata_.at(document_id).status};
        }
    }

    std::vector<std::string_view> matched_words{};
    for (std::string_view word_sv : query.plus_words) {
        const std::string& word = std::string(word_sv);
        if (__word_to__id_freq_.count(word) == 0) { continue; }
        if (__word_to__id_freq_.at(word).count(document_id) > 0) {
            matched_words.push_back(word_sv);
            //std::cout << word << std::endl;
        }
    }

    sort(matched_words.begin(), matched_words.end());
    //auto it = unique(matched_words.begin(), matched_words.end());
    //matched_words.erase(it, matched_words.end());

    return {matched_words, __id_docdata_.at(document_id).status};
}

std::tuple<std::vector<std::string_view>, DocumentStatus> SearchServer::MatchDocument
    (const std::execution::sequenced_policy& policy, std::string_view raw_query, int document_id) const
{
    //for (size_t i = 1; i <= 40000; ++i) { if ( (i / sqrt(i)) > 100'000'0) { std::cout << "OK" << std::endl; } }

    if (count(policy, __id_.begin(), __id_.end(), document_id) == 0) {
        throw std::out_of_range("Id doesn't exist");
    }

    // Empty result by initializing it with default constructed tuple
    const auto& query = ParseQuery(raw_query);

    auto& words_in_document = __id_to__word_freq_.at(document_id);
    if (words_in_document.empty()) {
        return {{}, __id_docdata_.at(document_id).status};
    }
    int minus_words_counter = transform_reduce(
        policy,
        query.minus_words.begin(),
        query.minus_words.end(),
        0,
        std::plus<>{},
        [&words_in_document](std::string_view word) {
        return words_in_document.count(std::string(word));
    });
    if (minus_words_counter > 0) {
        return {{}, __id_docdata_.at(document_id).status};
    }
    // Инициализuint64ация через конструктор
    std::vector<std::string_view> matched_words(query.plus_words.size());

    const auto& it_end = copy_if(policy,
                                 query.plus_words.begin(),
                                 query.plus_words.end(),
                                 matched_words.begin(),
                                 [&words_in_document](std::string_view word){
                                     return (words_in_document.count(std::string(word)) > 0);
                                 }
                         );
    matched_words.erase(it_end, matched_words.end());

    sort(policy, matched_words.begin(),matched_words.end());
    //auto it = unique(policy, matched_words.begin(), matched_words.end());
    //matched_words.erase(it, matched_words.end());
    //Удаление пустых строк в массиве, после удаления дубликатов
    //if (*matched_words.begin() == ""s) { matched_words.erase(matched_words.begin()); }

    return {matched_words, __id_docdata_.at(document_id).status};
}

std::tuple<std::vector<std::string_view>, DocumentStatus> SearchServer::MatchDocument
    (const std::execution::parallel_policy& policy, std::string_view raw_query, int document_id) const
{
/*
    if (count(policy, __id_.begin(), __id_.end(), document_id) == 0) {
        throw std::out_of_range("Id doesn't exist");
    }

    if (raw_query.empty()) {
        throw std::out_of_range("The query is empty");
    }
*/
    const std::map<std::string, double>& words_in_document = __id_to__word_freq_.at(document_id);
    if (words_in_document.empty()) {
        return {{}, __id_docdata_.at(document_id).status};
    }

    const SearchServer::Query& query = ParseQuery(raw_query);

    bool is_minus_words_ = std::any_of(//policy,
                                       query.minus_words.begin(), query.minus_words.end(),
                                       [&words_in_document](std::string_view word) {
                                            return words_in_document.find(std::string(word)) != words_in_document.end();
                                       });

    if (is_minus_words_ == true) {
        return {{}, __id_docdata_.at(document_id).status};
    }

    // Инициализация через конструктор
    std::vector<std::string_view> matched_words(query.plus_words.size());

    const auto& it_end = copy_if(//policy,
                                 query.plus_words.begin(),
                                 query.plus_words.end(),
                                 matched_words.begin(),
                                 [&words_in_document](std::string_view word){
                                     return (words_in_document.find(std::string(word)) != words_in_document.end());
                                 }
                         );
    matched_words.erase(it_end, matched_words.end());

    sort(matched_words.begin(),matched_words.end());
    //auto it = unique(policy, matched_words.begin(), matched_words.end());
    //matched_words.erase(it, matched_words.end());

    return {matched_words, __id_docdata_.at(document_id).status};
}

const std::map<std::string, double>& SearchServer::GetWordFrequencies(int document_id) const {
    //LOG_DURATION("GetWordFreq"s);
    static const std::map<std::string, double> empty_map = {};

    if (__id_to__word_freq_.at(document_id).empty()) {
        return empty_map;
    }
    return __id_to__word_freq_.at(document_id);
}

void SearchServer::RemoveDocument(int document_id) {
    if (!__id_docdata_.count(document_id)) { return; }

    for (const auto& [word, freq] : __id_to__word_freq_.at(document_id)) {
        __word_to__id_freq_[word].erase(document_id);
        if (__word_to__id_freq_[word].empty()) {
            __word_to__id_freq_.erase(word);
        }
    }
    // map<int, set<string>>
    __id_docdata_.erase(document_id);

    // set<int>
    __id_.erase(document_id);

    // map<int, map<string, double>>
    __id_to__word_freq_.erase(document_id);
}

void SearchServer::RemoveDocument(const std::execution::sequenced_policy& policy, int document_id) {
    if (!__id_docdata_.count(document_id)) { return; }

    __id_docdata_.erase(document_id);

    const map<string, double>& word_freqs = __id_to__word_freq_.at(document_id);
    vector<const string*> ptr_words(word_freqs.size());
    transform(policy, word_freqs.begin(), word_freqs.end(), ptr_words.begin(),
            [](const std::pair<const std::string, double>& doc_freq) {
                return &doc_freq.first;
            }
    );
    for_each(policy, ptr_words.begin(), ptr_words.end(),
            [document_id, this](const std::string* const& ptr){
                __word_to__id_freq_.at(*ptr).erase(document_id);
            }
    );

    __id_docdata_.erase(document_id);
    __id_.erase(document_id);
    __id_to__word_freq_.erase(document_id);
}

void SearchServer::RemoveDocument(const std::execution::parallel_policy& policy, int document_id) {
    if (!__id_docdata_.count(document_id)) { return; }

    __id_docdata_.erase(document_id);

    const map<string, double>& word_freqs = __id_to__word_freq_.at(document_id);
    vector<const string*> ptr_words(word_freqs.size());
    transform(policy, word_freqs.begin(), word_freqs.end(), ptr_words.begin(),
            [](const std::pair<const std::string, double>& doc_freq) {
                return &doc_freq.first;
            }
    );
    for_each(policy, ptr_words.begin(), ptr_words.end(),
            [document_id, this](const std::string* const& ptr) {
                __word_to__id_freq_.at(*ptr).erase(document_id);
            }
    );

    __id_docdata_.erase(document_id);
    __id_.erase(document_id);
    __id_to__word_freq_.erase(document_id);
}

//private

bool SearchServer::IsStopWord(std::string_view word) const {
    return __stopwords_.count(std::string(word)) > 0;
}

bool SearchServer::IsValidWord(std::string_view word) {
    // A valid word must not contain special characters
    using namespace std::string_literals;
    return none_of(word.begin(), word.end(),
        [](const char c) {
            return c >= '\0' && c < ' ';
        }
    );
}

std::vector<std::string_view> SearchServer::SplitIntoWordsNoStop(std::string_view text) const {
    std::vector<std::string_view> words;
    for (std::string_view word_sv : SplitIntoWords(text)) {
        const std::string& word = std::string(word_sv);
        if (!SearchServer::IsValidWord(word_sv)) {
            throw std::invalid_argument("Word "s + word + " is invalid"s);
        }
        if (!SearchServer::IsStopWord(word_sv)) {
            words.push_back(word_sv);
            //std::cout << word << std::endl;
        }
    }
    return words;
}

int SearchServer::ComputeAverageRating(const std::vector<int>& ratings) {
    int rating_sum = 0;
    for (const int rating : ratings) {
        rating_sum += rating;
    }
    return rating_sum / static_cast<int>(ratings.size());
}

SearchServer::QueryWord SearchServer::ParseQueryWord(std::string_view text) const {
    if (text.empty()) {
        throw std::invalid_argument("Query word is empty"s);
    }

    bool is_minus = false;
    if (text[0] == '-') {
        is_minus = true;
        text = text.substr(1);
    }
    string word = std::string(text);
    if (text.empty() || text[0] == '-' || !SearchServer::IsValidWord(word)) {
        throw std::invalid_argument("Query word "s + word + " is invalid");
    }

    return {text, is_minus, SearchServer::IsStopWord(word)};
}

SearchServer::Query SearchServer::ParseQuery(std::string_view text) const {

    SearchServer::Query result;
    for (std::string_view word_sv : SplitIntoWords(text)) {
        auto query_word = SearchServer::ParseQueryWord(word_sv);
        if (!query_word.is_stop) {
            if (query_word.is_minus) {
                result.minus_words.push_back(query_word.data);
            }
            else {
                result.plus_words.push_back(query_word.data);
            }
        }
    }

    sort(result.minus_words.begin(), result.minus_words.end());
    auto it_minus = unique(result.minus_words.begin(), result.minus_words.end());
    result.minus_words.erase(it_minus, result.minus_words.end());

    sort(result.plus_words.begin(), result.plus_words.end());
    auto it_plus = unique(result.plus_words.begin(), result.plus_words.end());
    result.plus_words.erase(it_plus, result.plus_words.end());

    return result;
}

double SearchServer::ComputeWordInverseDocumentFreq(std::string_view word) const {
    return log(SearchServer::GetDocumentCount() * 1.0 / __word_to__id_freq_.at(std::string(word)).size());
}

// ----END OF CLASS-----

