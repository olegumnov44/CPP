#pragma once

#include "search_server.h"

std::vector<std::vector<Document>> ProcessQueries_legacy(
    const SearchServer& search_server, const std::vector<std::string_view>& queries) {

    std::vector<std::vector<Document>> documents_;
    for (const std::string_view& query_sv : queries) {
        const std::string& query = std::string(query_sv);
        documents_.push_back(search_server.FindTopDocuments(query));
    }
    return documents_;
}

std::vector<std::vector<Document>> ProcessQueries(
    const SearchServer& search_server, const std::vector<std::string>& queries) {

    std::vector<std::vector<Document>> documents_(queries.size());
    transform(std::execution::par,
        queries.begin(),
        queries.end(),
        documents_.begin(),
        [&](const std::string& s) { return search_server.FindTopDocuments(s); }
    );
    return documents_;
}

std::vector<Document> ProcessQueriesJoined_legacy(
    const SearchServer& search_server, const std::vector<std::string>& queries) {
    LOG_DURATION("ProcessQueriesJoined_legacy"s);

    std::vector<Document> documents_;
    for (const auto& doc : ProcessQueries(search_server, queries)) {
        documents_.insert(documents_.end(), doc.begin(), doc.end());
    }
    return documents_;
}

std::list<Document> ProcessQueriesJoined(
    const SearchServer& search_server, const std::vector<std::string>& queries) {
    LOG_DURATION("ProcessQueriesJoined"s);
    //std::vector<std::vector<Document>> container = ProcessQueries(search_server, queries);

    std::list<Document> documents_;
    for (const auto& doc : ProcessQueries(search_server, queries)) {
        documents_.insert(documents_.end(), doc.begin(), doc.end());
    }
    return documents_;
}

     /*
        std::vector<Document> result;
        result.reserve(20000);
        size_t result_size = 0;

        std::for_each(std::execution::par, queries.begin(), queries.end(),
                      [&search_server, &result, &result_size](std::string qry) {
                          auto v = search_server.FindTopDocuments(qry);
                          result.resize(result.size() + v.size());
                          std::move(std::make_move_iterator(v.begin()),
                                    std::make_move_iterator(v.end()),
                                    result.begin() + result_size);
                          result_size += v.size();
                       });
    */
/*
        std::vector<std::vector<Document>> documents(queries.size());

        size_t result_size = 0;
        std::transform(std::execution::par, queries.begin(), queries.end(),
            documents.begin(),
            [&](std::string query) {
                auto v = search_server.FindTopDocuments(query);
                result_size += v.size();
                return v;
            });
*/
/*
    std::vector<Document> result(container.size());
        auto it = result.begin();
        std::for_each(std::execution::par, container.begin(), container.end(),
            [&](const std::vector<Document>& v) {
                //result.size();
                std::move(v.begin(), v.end(), result.end());
                //advance(it, v.size());
            });
        return result;
*/

/*
    std::transform_inclusive_scan(std::execution::par, queries.begin(), queries.end(),
        __id_docdata_lists.begin(),
        [](std::vector<Document>& v){
            return std::list<Document>(std::move(v.begin()), std::move(v.end()));
        },
        [&](const std::string& query){
            return search_server.FindTopDocuments(query);
        }
        );
*/
/*
    std::transform(std::execution::par, container.begin(), container.end(),
        __id_docdata_lists.end(),
        [&](std::vector<Document>& v){
            return std::reduce(v.begin(), v.end());
        }
    );
*/
/*
    transform_reduce(container.begin(), container.end(), // входной диапазон (парные значения)
    __id_docdata_lists.begin(),                        // входной диапазон (начало)
    {},                                              // init - начальное значение
    std::plus<>{},                                  // reduce-операция (группирующая бинарная функция - сложение)
    [&](std::vector<Document>& v) {
        return std::reduce(std::make_move_iterator(v.begin()), std::make_move_iterator(v.end()));          // map-операция
    }
    );
*/
/*
    for_each(std::execution::par, container.begin(), container.end(),
             [&](const std::vector<Document>& v) {
                 for (auto doc : v) {
                     __id_docdata_lists.push_back(doc);
                 }
             }
    );
*/
