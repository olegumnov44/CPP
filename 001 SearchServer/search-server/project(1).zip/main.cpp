#include <algorithm>
#include <cmath>
#include <deque>
#include <iostream>
#include <iomanip>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "search_server.h"
#include "request_queue.h"
#include "document.h"
#include "paginator.h"
#include "read_input_functions.h"
#include "string_processing.h"

#include "log_duration.h"
#include "test_example_functions.h"
#include "process_queries.h"

using namespace std;
//using namespace std::string_literals;

/*
--Задание 2
Это задание — часть итогового проекта восьмого спринта.
Вы будете сдавать его на проверку через репозиторий на GitHub.
Не забудьте сохранить верное решение.
Реализуйте многопоточную версию метода MatchDocument в дополнение к однопоточной.
--Ограничения
Как и прежде, в метод MatchDocument может быть передан некорректный поисковый запрос
— в этом случае должно быть выброшено исключение std::invalid_argument.
Если передан несуществующий document_id, ожидается исключение std::out_of_range.
--Что отправлять на проверку
Заголовочные файлы и файлы с реализацией, содержащие класс SearchServer
и написанные ранее вспомогательные функции. Функция main будет проигнорирована.
--Как будет тестироваться ваш код
Правильность работы метода будет проверена юнит-тестами.
Производительность всех версий метода будет проверена в таком тестовом сценарии.
Дана поисковая система с характеристиками:

    10 000 документов, не более 70 слов в каждом;
    не более 500 слов в поисковом запросе, включая минус-слова;
    все слова — из словаря, состоящего из 1 000 слов длиной не более 10 букв.

Дан поисковый запрос, состоящий из не более 500 слов, включая минус-слова.
Последовательно для всех документов вызывается MatchDocument с этим запросом.
Измеряется общее время работы цикла вызовов.
Для многопоточной версии вашего метода это время должно быть по крайней мере на 30% меньше,
чем у авторской однопоточной версии.
Также это время должно быть по крайней мере на 30% меньше,
чем у вашей однопоточной версии в обоих вариантах вызова.
--Подсказка
Иногда для получения эффективного параллельного кода недостаточно поменять код самого метода.
Приходится вносить изменения в другие методы, от которых зависит оптимизируемый.
Скорее всего, здесь как раз тот случай.
Не любое ускорение означает именно распараллеливание.
Вероятно, вам поможет взглянуть на задачу чуть шире — как на приведение в соответствие бенчмарку.
*/

void AddDocument(SearchServer& search_server, int document_id, const std::string& document,
                 DocumentStatus status, const std::vector<int>& ratings)
{
    try {
        search_server.AddDocument(document_id, document, status, ratings);
    }
    catch (const std::exception& e) {
        std::cout << "Error in adding document "s << document_id << ": "s << e.what() << std::endl;
    }
}

void FindTopDocuments(const SearchServer& search_server, std::string_view raw_query) {
    std::cout << "Results for request: "s << std::string(raw_query) << std::endl;
    try {
        for (const Document& document : search_server.FindTopDocuments(raw_query)) {
            PrintDocument(document);
        }
    }
    catch (const std::exception& e) {
        std::cout << "Error is seaching: "s << e.what() << std::endl;
    }
}

void MatchDocuments(const SearchServer& search_server, std::string_view query) {
    try {
        std::cout << "Matching for request: "s << query << std::endl;
        for (auto index = search_server.begin(); index != search_server.end(); ++index) {
            const int document_id = *index;
            const auto [words, status] = search_server.MatchDocument(query, document_id);
            PrintMatchDocumentResult(document_id, words, status);
        }
    }
    catch (const std::exception& e) {
        std::cout << "Error in matchig request "s << query << ": "s << e.what() << std::endl;
    }
}


int main() {

    SearchServer search_server("and with or"s);

    int id = 0;
    for (
        const string& text : {
            "funny pet and nasty rat"s,
            "funny pet with curly hair"s,
            "funny pet and not very nasty rat"s,
            "pet with rat and rat and rat"s,
            "nasty rat with curly hair"s,
        }
    )
    {
        search_server.AddDocument(++id, text, DocumentStatus::ACTUAL, {1, 2});
    }

    const string query = "curly and funny -not"s;

    {
        const auto [words, status] = search_server.MatchDocument(query, 1);
        cout << words.size() << " words for document 1"s << endl;
        // 1 words for document 1
    }

    {
        const auto [words, status] = search_server.MatchDocument(execution::seq, query, 2);
        cout << words.size() << " words for document 2"s << endl;
        // 2 words for document 2
    }

    {
        const auto [words, status] = search_server.MatchDocument(execution::par, query, 3);
        cout << words.size() << " words for document 3"s << endl;
        // 0 words for document 3
    }

    {
        mt19937 generator;

        const auto dictionary = GenerateDictionary(generator, 1000, 10);
        const auto documents = GenerateQueries(generator, dictionary, 10'00, 70);

        const string query = GenerateQuery(generator, dictionary, 500, 0.1);

        SearchServer search_server(dictionary[0]);
        for (size_t i = 0; i < documents.size(); ++i) {
            search_server.AddDocument(i, documents[i], DocumentStatus::ACTUAL, {1, 2, 3});
        }

        TEST_legacy(legacy);
        TEST(seq);
        TEST(par);
    }

    return 0;
}
