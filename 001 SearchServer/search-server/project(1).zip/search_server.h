#pragma once

#include <algorithm>
#include <cmath>
#include <deque>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include <tuple>
#include <execution>
#include <numeric>
#include <list>
#include <iostream>
#include <iterator>

#include "document.h"
#include "string_processing.h"
#include "log_duration.h"

using namespace std::string_literals;

const int MAX_RESULT_DOCUMENT_COUNT = 5;
const double MIN_ACCURACY = 1e-6;


class SearchServer
{
public:
    template <typename StringContainer>
    explicit SearchServer(const StringContainer& stop_words);
    explicit SearchServer(std::string_view stopwords_text);
    explicit SearchServer(const std::string& text);

    void AddDocument(int document_id, std::string_view document, DocumentStatus status, const std::vector<int>& ratings);

    template <typename DocumentPredicate>
    std::vector<Document> FindTopDocuments(std::string_view raw_query, DocumentPredicate document_predicate) const;
    std::vector<Document> FindTopDocuments(std::string_view raw_query, DocumentStatus status) const;
    std::vector<Document> FindTopDocuments(std::string_view raw_query) const;

    int GetDocumentCount() const;

    std::set<int>::const_iterator begin() const;
    std::set<int>::const_iterator end() const;

    std::tuple<std::vector<std::string_view>, DocumentStatus> MatchDocument(std::string_view raw_query,
                                                                            int document_id) const;
    std::tuple<std::vector<std::string_view>, DocumentStatus> MatchDocument(const std::execution::sequenced_policy& policy,
                                                                            std::string_view raw_query, int document_id) const;
    std::tuple<std::vector<std::string_view>, DocumentStatus> MatchDocument(const std::execution::parallel_policy& policy,
                                                                            std::string_view raw_query, int document_id) const;

    const std::map<std::string, double>& GetWordFrequencies(int document_id) const;

    void RemoveDocument(int document_id);
    void RemoveDocument(const std::execution::sequenced_policy& policy, int document_id);
    void RemoveDocument(const std::execution::parallel_policy& policy, int document_id);

private:
    struct DocumentData {
        int rating;
        DocumentStatus status;
    };

    std::set<std::string, std::less<>> __stopwords_; //stop_words_  //word_to_document_freqs_; _id_to_word_freqs_
    std::map<std::string, std::map<int, double>, std::less<>> __word_to__id_freq_; // {<word{<id, freq>}>}
    std::map<int, DocumentData> __id_docdata_; // documents_
    std::set<int> __id_; //document_id_
    std::map<int, std::map<std::string, double>, std::less<>> __id_to__word_freq_; // {<id{<word, freq>}>}

    bool IsStopWord(std::string_view word) const;

    static bool IsValidWord(std::string_view word);

    std::vector<std::string_view> SplitIntoWordsNoStop(std::string_view text) const;

    static int ComputeAverageRating(const std::vector<int>& ratings);

    struct QueryWord
    {
        std::string_view data;
        bool is_minus;
        bool is_stop;
    };

    QueryWord ParseQueryWord(std::string_view text) const;

    struct Query {
        std::vector<std::string_view> plus_words;
        std::vector<std::string_view> minus_words;
    };

    Query ParseQuery(std::string_view text) const;

    template <typename ExecutionPolicy>
    SearchServer::Query ParseQuery(const ExecutionPolicy& policy, std::string_view text) const {

        SearchServer::Query result;
        std::vector<std::string_view> words = SplitIntoWords(text);

        std::vector<std::string_view> ptr_words(SplitIntoWords(text).size());
/*
        transform(
                  words.begin(),
                  words.end(),
                  ptr_words.begin(),
                  [](std::string_view word) {
                      return word;
                  }
        );
*/
        for_each(
                 words.begin(),
                 words.end(),
                 [&result, this](std::string_view word) {
                     const SearchServer::QueryWord& query_word = SearchServer::ParseQueryWord(word);
                     if (!query_word.is_stop) {
                         if (query_word.is_minus) { result.minus_words.push_back(query_word.data); }
                         else { result.plus_words.push_back(query_word.data); }
                     }
                 }
        );

        sort(result.minus_words.begin(), result.minus_words.end());
        auto it_minus = unique(result.minus_words.begin(), result.minus_words.end());
        result.minus_words.erase(it_minus, result.minus_words.end());

        sort(result.plus_words.begin(), result.plus_words.end());
        auto it_plus = unique(result.plus_words.begin(), result.plus_words.end());
        result.plus_words.erase(it_plus, result.plus_words.end());

        return result;
    }

    // Existence required
    double ComputeWordInverseDocumentFreq(std::string_view word) const;

    template <typename DocumentPredicate>
    std::vector<Document> FindAllDocuments(const Query& query, DocumentPredicate document_predicate) const;
};

template <typename StringContainer>
SearchServer::SearchServer(const StringContainer& stop_words)
    //: __stopwords_(MakeUniqueNonEmptyStrings(stop_words))
{
    if (std::any_of(stop_words.cbegin(), stop_words.cend(),
                    [](std::string_view word){ return !IsValidWord(word); })) {
        throw std::invalid_argument("Found a special symbol(s)"s);
    }

    for (const std::string_view& word_sv : stop_words) {       // Extract non-empty stop words
        const std::string& word = std::string(word_sv);
        if (!word.empty()) {
            __stopwords_.insert(word);
        }
    }
}

template <typename DocumentPredicate>
std::vector<Document> SearchServer::FindTopDocuments(std::string_view raw_query,
                                                     DocumentPredicate document_predicate) const
{
    const SearchServer::Query query = SearchServer::ParseQuery(raw_query);

    std::vector<Document> matched_documents = SearchServer::FindAllDocuments(query, document_predicate);

    sort(matched_documents.begin(), matched_documents.end(),
         [](const Document& lhs, const Document& rhs) {
             return lhs.relevance > rhs.relevance
                 || (std::abs(lhs.relevance - rhs.relevance) < MIN_ACCURACY && lhs.rating > rhs.rating);
         });
    if (matched_documents.size() > MAX_RESULT_DOCUMENT_COUNT) {
        matched_documents.resize(MAX_RESULT_DOCUMENT_COUNT);
    }
    return matched_documents;
}

template <typename DocumentPredicate>
std::vector<Document> SearchServer::FindAllDocuments(const Query& query,
                                                     DocumentPredicate document_predicate) const
{
    std::map<int, double> document_to_relevance;
    for (const std::string_view& word_sv : query.plus_words) {
        const std::string& word = std::string(word_sv);
        if (__word_to__id_freq_.count(word) == 0) {
            continue;
        }
        const double inverse_document_freq = SearchServer::ComputeWordInverseDocumentFreq(word);
        for (const auto [document_id, term_freq] : __word_to__id_freq_.at(word)) {
            const auto& document_data = __id_docdata_.at(document_id);
            if (document_predicate(document_id, document_data.status, document_data.rating)) {
                document_to_relevance[document_id] += term_freq * inverse_document_freq;
            }
        }
    }
    for (const std::string_view& word_sv : query.minus_words) {
        const std::string& word = std::string(word_sv);
        if (__word_to__id_freq_.count(word) == 0) {
            continue;
        }
        for (const auto [document_id, _] : __word_to__id_freq_.at(word)) {
            document_to_relevance.erase(document_id);
        }
    }

    std::vector<Document> matched_documents;
    for (const auto [document_id, relevance] : document_to_relevance) {
        matched_documents.push_back( {document_id, relevance, __id_docdata_.at(document_id).rating} );
    }
    return matched_documents;
}
