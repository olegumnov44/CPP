#pragma once

#include <string>

#include "paginator.h"

std::string ReadLine();

int ReadLineWithNumber();
