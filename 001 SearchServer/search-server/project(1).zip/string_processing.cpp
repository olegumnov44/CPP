#include <iostream>
#include <string>
#include <vector>

#include "string_processing.h"

using namespace std;

std::vector<std::string_view> SplitIntoWords(std::string_view text)
{
    std::vector<std::string_view> words;
    auto it_first = text.find_first_not_of(' ', 0);
    size_t first = it_first - 0;
    do {
        auto second = text.find_first_of(' ', first);
        if (first != second) {
            words.emplace_back(text.substr(first, second-first));
            //std::cout << text.substr(first, second-first) << " ";
        }
        //if (second == std::string_view::npos) { break; }
        first = text.find_first_not_of(' ', second);
    }
    while(first < text.size());

    return words;
}

/*
std::vector<std::string_view> SplitIntoWords(std::string_view text)
{
    std::vector<std::string_view> words;
    std::string_view word;
    for (const char c : text) {
        //std::cout << c << std::endl;
        if (c == ' ') {
            if (!word.empty()) {
                //std::cout << word << std::endl;
                words.push_back(word);
                //word.clear();
            }
        }
        else { word[c]; }
    }
    if (!word.empty()) { std::cout << word << std::endl; words.push_back(word); }
    return words;
}
*/
